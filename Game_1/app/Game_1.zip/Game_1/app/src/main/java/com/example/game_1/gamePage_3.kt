package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class gamePage_3 : AppCompatActivity() {

    lateinit var dec_1_1: Button
    lateinit var dec_1_2: Button
    lateinit var dec_1_3: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page3)

        dec_1_1 = findViewById(R.id.dec_1_1)
        dec_1_2 = findViewById(R.id.dec_1_2)
        dec_1_3 = findViewById(R.id.dec_1_3)

        dec_1_1.setOnClickListener {
            toPlot_2_dec_1_1()
        }
        dec_1_2.setOnClickListener {
            toPlot_2_dec_1_2()
        }
        dec_1_3.setOnClickListener {
            toEpilogue_1()
        }
    }

    fun toPlot_2_dec_1_1(){
        val Intent = Intent (this, gamePage_4::class.java)
        startActivity(Intent)
    }
    fun toPlot_2_dec_1_2(){
        val Intent = Intent (this, gamePage_10::class.java)
        startActivity(Intent)
    }
    fun toEpilogue_1(){
        val Intent = Intent (this, gamePage_12::class.java)
        startActivity(Intent)
    }
}