package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class gamePage_12 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page12)

        val handler = android.os.Handler()
        val runnable = Runnable {
            val intent = Intent(this, gamePage_9::class.java)  // Replace with your actual next activity class
            intent.putExtra("epilogue_1", 5)
            startActivity(intent)
        }
        handler.postDelayed(runnable, 5000)
    }
}