package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class gamePage_2 : AppCompatActivity() {

    lateinit var skipBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page2)

        val handler = android.os.Handler()
        val runnable = Runnable {
            val intent = Intent(this, gamePage_3::class.java)  // Replace with your actual next activity class
            startActivity(intent)
        }
        handler.postDelayed(runnable, 15000)

        skipBtn = findViewById(R.id.skipBtn_1)

        skipBtn.setOnClickListener {
            skip()
        }
    }

    fun skip(){
        val Intent = Intent (this, gamePage_3::class.java)
        startActivity(Intent)
    }
}