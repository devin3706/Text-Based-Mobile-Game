package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class gamePage_9 : AppCompatActivity() {

    lateinit var backToStart: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page9)

        val intent = intent
        val fromPlot_1 = intent.getIntExtra("epilogue_1", -5)
        val intellect = intent.getIntExtra("intellect", -1)

        if(fromPlot_1 == 5){
            val status = "failed"
            val attitude = "none"
            val intellect = "none"
            val objective = findViewById<TextView>(R.id.objective)
            objective.text = status
            val att = findViewById<TextView>(R.id.attd)
            att.text = attitude
            val intel = findViewById<TextView>(R.id.intlct)
            intel.text = intellect
        }
        if (intellect == 1){
            val status = "passed"
            val attitude = "confident"
            val intellect = "good"
            val objective = findViewById<TextView>(R.id.objective)
            objective.text = status
            val att = findViewById<TextView>(R.id.attd)
            att.text = attitude
            val intel = findViewById<TextView>(R.id.intlct)
            intel.text = intellect
        }

        backToStart = findViewById(R.id.backToStart)

        backToStart.setOnClickListener {
            toStart()
        }
    }

    fun toStart(){
        val Intent = Intent (this, onBoarding_page_2::class.java)
        startActivity(Intent)
    }
}