package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class gamePage_8 : AppCompatActivity() {

    lateinit var skipBtn_2: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page8)

        val intent = intent
        val intellect = intent.getIntExtra("intellect", -1)

        skipBtn_2 = findViewById(R.id.skipBtn_2)

        skipBtn_2.setOnClickListener {
            skip()
        }

        val handler = android.os.Handler()
        val runnable = Runnable {
            val intent = Intent(this, gamePage_9::class.java)
            if (intellect == 1){
                intent.putExtra("intellect", 1)
            }
            startActivity(intent)
        }
        handler.postDelayed(runnable, 15000)
    }

    fun skip(){
        val Intent = Intent(this, gamePage_9::class.java)
        startActivity(Intent)
    }
}