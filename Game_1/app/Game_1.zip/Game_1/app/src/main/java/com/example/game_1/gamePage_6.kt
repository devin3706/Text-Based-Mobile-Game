package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class gamePage_6 : AppCompatActivity() {

    lateinit var dec_4_1_31: Button
    lateinit var dec_4_2_31: Button
    lateinit var dec_4_3_31: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page6)

        dec_4_1_31 = findViewById(R.id.dec_4_1_31)
        dec_4_2_31 = findViewById(R.id.dec_4_2_31)
        dec_4_3_31 = findViewById(R.id.dec_4_3_31)

        dec_4_1_31.setOnClickListener {
            toBridge_1_dec_4_1()
        }
        dec_4_2_31.setOnClickListener {
            toBridge_1_dec_4_2()
        }
        dec_4_3_31.setOnClickListener {
            toSectDetails_dec_4_3()
        }
    }

    fun toBridge_1_dec_4_1(){
        val Intent = Intent (this, gamePage_7::class.java)
        Intent.putExtra("bridge_1", 1)
        startActivity(Intent)
    }
    fun toBridge_1_dec_4_2(){
        val Intent = Intent (this, gamePage_7::class.java)
        Intent.putExtra("bridge_1", 2)
        startActivity(Intent)
    }
    fun toSectDetails_dec_4_3(){
        val Intent = Intent (this, gamePage_7::class.java)
        Intent.putExtra("bridge_1", 3)
        startActivity(Intent)
    }
}