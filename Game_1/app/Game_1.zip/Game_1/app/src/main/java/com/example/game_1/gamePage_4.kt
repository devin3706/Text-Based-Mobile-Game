package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class gamePage_4 : AppCompatActivity() {

    lateinit var dec_2_1_11: Button
    lateinit var dec_2_2_11: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page4)

        dec_2_1_11 = findViewById(R.id.dec_2_1_11)
        dec_2_1_11 = findViewById(R.id.dec_2_2_11)

        dec_2_1_11.setOnClickListener {
            toPlot_3_dec_2_1()
        }
        dec_2_2_11.setOnClickListener {
            toPlot_3_dec_2_2()
        }
    }

    fun toPlot_3_dec_2_1(){
        val Intent = Intent (this, gamePage_5::class.java)
        startActivity(Intent)
    }
    fun toPlot_3_dec_2_2(){
        val Intent = Intent (this, gamePage_5::class.java)
        startActivity(Intent)
    }
}