package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class gamePage_10 : AppCompatActivity() {

    lateinit var dec_3_1_12: Button
    lateinit var dec_3_2_12: Button
    lateinit var dec_3_3_12: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page10)

        dec_3_1_12 = findViewById(R.id.dec_3_1_12)
        dec_3_2_12 = findViewById(R.id.dec_3_2_12)
        dec_3_3_12 = findViewById(R.id.dec_3_3_12)

        dec_3_1_12.setOnClickListener {
            toPlot_4_dec_2_1()
        }
        dec_3_2_12.setOnClickListener {
            toPlot_4_dec_2_2()
        }
        dec_3_3_12.setOnClickListener {
            toPlot_4_dec_2_3()
        }
    }

    fun toPlot_4_dec_2_1(){
        val Intent = Intent (this, gamePage_6::class.java)
        startActivity(Intent)
    }
    fun toPlot_4_dec_2_2(){
        val Intent = Intent (this, gamePage_7::class.java)
        Intent.putExtra("epilogue_2", 3)
        startActivity(Intent)
    }
    fun toPlot_4_dec_2_3(){
        val Intent = Intent (this, gamePage_6::class.java)
        startActivity(Intent)
    }
}