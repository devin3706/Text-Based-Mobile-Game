package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class onBoarding_page_2 : AppCompatActivity() {

    lateinit var start: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_on_boarding_page2)

        start = findViewById(R.id.startBtn)

        start.setOnClickListener {
            startGame()
        }
    }

    fun startGame() {
        val Intent = Intent(this, gamePage_1::class.java)
        startActivity(Intent)
    }
}

