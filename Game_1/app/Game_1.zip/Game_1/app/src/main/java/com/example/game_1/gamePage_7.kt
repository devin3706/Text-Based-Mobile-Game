package com.example.game_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class gamePage_7 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page7)

        val intent = intent
        val fromPlot_4 = intent.getIntExtra("bridge_1", -1)
        val fromPlot_3 = intent.getIntExtra("epilogue_2", -2)
        val fromPlot_1 = intent.getIntExtra("epilogue_1", -5)

        val handler = android.os.Handler()
        val runnable = Runnable {
            if(fromPlot_4 != null){
                if (fromPlot_4 == 1) {
                    val intent = Intent(this, gamePage_8::class.java)
                    startActivity(intent)
                }else if (fromPlot_4 == 2) {
                    val intent = Intent(this, gamePage_8::class.java)
                    startActivity(intent)
                }else if (fromPlot_4 == 3) {
                    val intent = Intent(this, gamePage_8::class.java)
                    intent.putExtra("intellect", 1)
                    startActivity(intent)
                }else if (fromPlot_3 == 3) {
                    val intent = Intent(this, gamePage_11::class.java)
                    startActivity(intent)
                }else if (fromPlot_1 == 5) {
                    val intent = Intent(this, gamePage_12::class.java)
                    startActivity(intent)
                }
            }
        }
        handler.postDelayed(runnable, 3000)
    }
}